import 'package:flutter/material.dart';

void main() => runApp(const AmrutdharaApp());

class AmrutdharaApp extends StatelessWidget {
  const AmrutdharaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Amrutdhara Milk Delivery',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Amrutdhara Milk Delivery')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            const Icon(Icons.local_drink, size: 100),
            const SizedBox(height: 12),
            const Text('Fresh Milk at your doorstep', textAlign: TextAlign.center, style: TextStyle(fontSize: 18)),
            const Spacer(),
            FilledButton.icon(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const OrderScreen()));
              },
              icon: const Icon(Icons.shopping_bag),
              label: const Text('Order Milk'),
            ),
          ],
        ),
      ),
    );
  }
}

class OrderScreen extends StatelessWidget {
  const OrderScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Place Order')),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.delivery_dining, size: 80),
            const SizedBox(height: 12),
            const Text('Your milk is on the way 🚚', style: TextStyle(fontSize: 18)),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Back to Home'),
            )
          ],
        ),
      ),
    );
  }
}
