# Amrutdhara Milk Delivery Flutter App

This is a demo Flutter app for milk delivery.  
Upload this repo to GitHub and connect with Codemagic.  

### Build Steps (Codemagic)
1. Connect repo on Codemagic.
2. Select **YAML workflow**.
3. Start build.
4. Download `app-debug.apk` from Artifacts.
