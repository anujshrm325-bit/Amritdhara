# Amrutdhara Milk Delivery (Flutter Demo)

This is a minimal Flutter app ready for **Codemagic**. It will produce a **Debug APK** artifact.

## How to build on Codemagic
1. Connect this repo on Codemagic (Sign in with GitHub).
2. Choose the YAML workflow (codemagic.yaml).
3. Start build. Download `app-debug.apk` from Artifacts.
